import React from 'react'

export default function stock() {
    return (
        <div>
            <h1>stock</h1>
        </div>
    )
}
