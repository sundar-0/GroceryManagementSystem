import React from 'react'

export default function supplier() {
    return (
        <div>
            <h1>supplier</h1>
        </div>
    )
}
