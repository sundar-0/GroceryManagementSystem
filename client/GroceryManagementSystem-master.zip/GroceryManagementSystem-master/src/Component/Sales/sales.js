import React from 'react'

export default function sales() {
    return (
        <div>
            <h1>sales</h1>
        </div>
    )
}
