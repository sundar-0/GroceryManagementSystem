import React from 'react'

export default function report() {
    return (
        <div>
            <h1>report</h1>
        </div>
    )
}
