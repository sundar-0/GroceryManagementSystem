import React from 'react'

export default function customer() {
    return (
        <div>
            <h1>customer</h1>
        </div>
    )
}

